<?php
  session_start();
  include 'config.php';

  $update=false;
  $id="";
  $nombreproducto="";
  $referencia="";
  $precio="";
  $peso="";
  $categoria="";
  $stock="";
  $fechacreacion="";
  $fechaventa="";
  
  if(isset($_POST['add'])){
     $nombreproducto=$_POST['nombreproducto'];
     $referencia=$_POST['referencia'];
     $precio=$_POST['precio'];
     $peso=$_POST['peso'];
     $categoria=$_POST['categoria'];
     $stock=$_POST['stock'];
     $fechacreacion=$_POST['fechacreacion'];
     $fechaventa=$_POST['fechaventa'];

     $query="INSERT INTO producto(nombreproducto,referencia,precio,peso,categoria,stock,fechacreacion,fechaventa)VALUES(?,?,?,?,?,?,?,?)";
     $stmt=$conn->prepare($query);
     $stmt->bind_param("ssssssss",$nombreproducto,$referencia,$precio,$peso,$categoria,$stock,$fechacreacion,$fechaventa);
     $stmt->execute();

     header('location:index.php');
     $_SESSION['response']="¡Se ha Ingresado correctamente a la base de datos!";
     $_SESSION['res_type']="success";
  }

  if(isset($_GET['delete'])){
     $id=$_GET['delete'];

     $query="DELETE FROM producto WHERE id=?";
     $stmt=$conn->prepare($query);
     $stmt->bind_param("i",$id);
     $stmt->execute();
     header('location:index.php');
     $_SESSION['response']="¡Se ha Eliminado correctamente!";
     $_SESSION['res_type']="danger";
  }

  if(isset($_GET['edit'])){
   $id=$_GET['edit'];

   $query="SELECT * FROM producto WHERE id=?";
   $stmt=$conn->prepare($query);
   $stmt->bind_param("i",$id);
   $stmt->execute();
   $result=$stmt->get_result();
   $row=$result->fetch_assoc();

   $id=$row['id'];
   $nombreproducto=$row['nombreproducto'];
   $referencia=$row['referencia'];
   $precio=$row['precio'];
   $peso=$row['peso'];
   $categoria=$row['categoria'];
   $stock=$row['stock'];
   $fechacreacion=$row['fechacreacion'];
   $fechaventa=$row['fechaventa'];

   $update=true;

   

}

if(isset($_POST['update'])){
   $nombreproducto=$_POST['nombreproducto'];
   $referencia=$_POST['referencia'];
   $precio=$_POST['precio'];
   $peso=$_POST['peso'];
   $categoria=$_POST['categoria'];
   $stock=$_POST['stock'];
   $fechacreacion=$_POST['fechacreacion'];
   $fechaventa=$_POST['fechaventa'];

   
   $query="UPDATE producto SET nombreproducto=?,referencia=?,precio=?,peso=?,categoria=?,stock=?,fechacreacion=?,fechaventa=? WHERE id=?";
   $stmt=$conn->prepare($query);
   $stmt->bind_param("ssssssssi",$nombreproducto,$referencia,$precio,$peso,$categoria,$stock,$fechacreacion,$fechaventa, $id);
   $stmt->execute();

   $_SESSION['response']="Cargado Exitosamente!";
   $_SESSION['res_type']="primary";
   header('location:index.php');

}


?> 