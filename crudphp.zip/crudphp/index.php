<?php
 include 'action.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bases de datos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <link rel="stylesheet" href="style.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Crud de Productos</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Bases de Datos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Servicios</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Nosotros</a>
      </li>
    </ul>
</div>
  
  <form class="form-inline" action="/action_page.php">
    <input class="form-control mr-sm-2" type="text" placeholder="Buscar">
    <button class="btn btn-primary" type="submit">Buscar</button>
    </form>
</nav>
<div class="container-fluid">
    <div class="row justify-content-center">
       <div class="col-md-10">
         <h3 class="text-center text-dark mt-2">Bases de datos y CRUD de Datos 
         orientada a objetos</h3>
         <hr>
         <?php if(isset($_SESSION['response'])){ ?>
         <div class="alert alert-<?= $_SESSION['res_type']; ?> 
         alert-dismissible text-center">
         <button type="button" class="close" data-dismiss="alert">&times;
         </button>
         <b><?= $_SESSION['response']; ?></b>
        </div>
         <?php } unset($_SESSION['response']);?>
         </div>
       </div>
       <div class="row">
       <div class="col-md-4">
         <h3 class="text-center text-info">Agrega los datos</h3>
         <form action="action.php" method="post" enctype="multipart/form-data">
         <div class="form-group">
         <input type="hidden" name="id" value="<?= $id; ?>">
         <label for="exampleInputproducto">Nombre del Producto:</label>
           <input type="text" name="nombreproducto" value="<?= $nombreproducto; ?>"
           class="form-control" placeholder="Ingresa el nombre del producto" required>
         </div>
         <div class="form-group">
         <label for="exampleInputreferencia">Referencia:</label>
           <input type="number" name="referencia" class="form-control" value="<?= $referencia; ?>"
           placeholder="Ingresa la referencia" required>
         </div>
         <div class="form-group">
         <label for="exampleInputprecio">Precio:</label>
           <input type="text" name="precio" class="form-control" value="<?=  $precio; ?>"
           placeholder="Ingresa el precio" required>
         </div>
         <div class="form-group">
         <label for="exampleInputpeso">Peso:</label>
           <input type="text" name="peso" class="form-control" value="<?=  $peso; ?>"
           placeholder="Ingresa el peso" required>
         </div>
         <div class="form-group">
         <label for="exampleInputcategoria">Categoria:</label>
           <input type="text" name="categoria" class="form-control" value="<?=  $categoria; ?>"
           placeholder="Ingresa la categoria" required>
         </div>
         <div class="form-group">
         <label for="exampleInputprecio">Stock:</label>
           <input type="text" name="stock" class="form-control" value="<?=  $stock; ?>"
           placeholder="Ingresa el stock" required>
         </div>
         <div class="form-group">
         <label for="exampleInputprecio">Fecha de creacion:</label>
           <input type="text" name="fechacreacion" class="form-control" value="<?=  $fechacreacion; ?>"
           placeholder="Ingresa la fecha de creacion" required>
         </div>
         <div class="form-group">
         <label for="exampleInputprecio">Fecha de Venta:</label>
           <input type="text" name="fechaventa" class="form-control" value="<?=  $fechaventa; ?>"
           placeholder="Ingresa la fecha de venta" required>
         </div>
         <div class="form-group">
            <?php if ($update==true){?>
            <input type="submit" name="update" class="btn btn-success
            btn-block" value="Reenviar" required>
            <?php } else{ ?>
               <input type="hidden" name="add"  value="<?= $photo;  ?>">
               <input type="submit" name="add" class="btn btn-primary btn-block"
               value="Enviar">
               <?php } ?>
            </div>
         </form>
       </div>
       <div class="col-md-8">
         <?php
            $query="SELECT * FROM producto";
            $stmt=$conn->prepare($query);
            $stmt->execute();
            $result=$stmt->get_result();
            ?>
             <h3 class="text-center text-info">Bases de datos de productos</h3>
             <table class="table table-bordered">
    <thead>
      <tr>
        <th>id</th>
        <th>Nombre Producto</th>
        <th>Referencia</th>
        <th>Precio</th>
        <th>Peso</th>
        <th>Categoria</th>
        <th>Stock</th>
        <th>Fecha Creacion</th>
        <th>Fecha Venta</th>
        <th>Acciones</th>

      </tr>
    </thead>
    <tbody>
      <?php while($row=$result->fetch_assoc()){?>
      <tr>
        <td><?= $row['id'];?></td>
        <td><?= $row['nombreproducto'];?></td>
        <td><?= $row['referencia'];?></td>
        <td><?= $row['precio'];?></td>
        <td><?= $row['peso'];?></td>
        <td><?= $row['categoria'];?></td>
        <td><?= $row['stock'];?></td>
        <td><?= $row['fechacreacion'];?></td>
        <td><?= $row['fechaventa'];?></td>
        <td>
        <a href="index.php?edit=<?= $row['id']; ?>" class="badge 
        badge-success p-2">Editar</a>
        <a href="action.php?delete=<?= $row['id']; ?>" class="badge 
        badge-danger p-2" onclick="return confirm('Estas Seguro de Eliminarlo')";>Eliminar</a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
       </div>
       </div>
    </div>
    
        
</body>
</html>